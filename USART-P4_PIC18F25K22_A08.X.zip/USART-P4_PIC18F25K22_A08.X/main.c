//------------------------------------------------------------------------------
// File Name:USART1
// By: N.M
// C�digo para o V�deo: V31-Curso de programa��o PIC Modulo USART-P4
// Data:24/08/2019
// Por: Nivaldo Mattos
// uLab Eletr�nica
// email: ulabchannel@gmail.com 
// C�digo no GITHUB Ver na descri��o
//------------------------------------------------------------------------------
#include "mcc_generated_files/mcc.h"
//------------------------------------------------------------------------------
void main(void)
{
    // Initialize the device
    SYSTEM_Initialize();

    // If using interrupts in PIC18 High/Low Priority Mode you need to enable the Global High and Low Interrupts
    // If using interrupts in PIC Mid-Range Compatibility Mode you need to enable the Global and Peripheral Interrupts
    // Use the following macros to:

    // Enable the Global Interrupts
   INTERRUPT_GlobalInterruptEnable();

    // Disable the Global Interrupts
    //INTERRUPT_GlobalInterruptDisable();

    // Enable the Peripheral Interrupts
    INTERRUPT_PeripheralInterruptEnable();

    // Disable the Peripheral Interrupts
    //INTERRUPT_PeripheralInterruptDisable();

    uint8_t cont;
    while (1)
    {
        // Add your application code
        for(cont=0;cont<100;cont++) //1seg
            __delay_ms(10);
        printf(" A08- Clk=44.2368MHz 9600Bps\n");
    }
}
//------------------------------------------------------------------------------
// Rotina de recepcao da USART1
// Eh chamada sempre que chega um caracter pela serial
// Baudrate:9600bps
//------------------------------------------------------------------------------
void Usart1Main(uint8_t rcvByte)
{
   if(rcvByte=='a')
   {
        LED_AZ_Toggle();
   }
   else if(rcvByte=='b')
   {
        LED_VM_Toggle();
       //  printf("Recebida letra b ");
   }
   else if(rcvByte=='c')
   {
        LED_AM_Toggle();
      // printf("Recebida letra c ");
   }
   else if(rcvByte=='d')
   {
        LED_AZ_SetHigh();
        LED_VM_SetHigh();
        LED_AM_SetHigh();
   }
   else if(rcvByte=='e')
   {
        LED_AZ_SetLow();
        LED_VM_SetLow();
        LED_AM_SetLow();
   }
   
}
//------------------------------------------------------------------------------
// End of File
//------------------------------------------------------------------------------

   